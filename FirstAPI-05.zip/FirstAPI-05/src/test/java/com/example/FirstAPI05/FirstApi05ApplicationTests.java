package com.example.FirstAPI05;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstApi05ApplicationTests {

	@Test
	void contextLoads() {
	}

}
